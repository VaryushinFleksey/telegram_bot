import threading
import time
import requests
from bot_log import logger

def keep_alive():
    """Функция для поддержания активности на Render"""
    while True:
        try:
            # После деплоя замените YOUR_RENDER_URL на URL вида https://your-app-name.onrender.com
            url = "YOUR_RENDER_URL"
            response = requests.get(url)
            logger.info(f"Keep-alive ping sent. Status: {response.status_code}")
        except Exception as e:
            logger.error(f"Keep-alive error: {e}")
        
        # Ждем 5 минут
        time.sleep(300)

def start_keep_alive():
    """Запускает поддержание активности в отдельном потоке"""
    keep_alive_thread = threading.Thread(target=keep_alive, daemon=True)
    keep_alive_thread.start()
    logger.info("Keep-alive thread started") 